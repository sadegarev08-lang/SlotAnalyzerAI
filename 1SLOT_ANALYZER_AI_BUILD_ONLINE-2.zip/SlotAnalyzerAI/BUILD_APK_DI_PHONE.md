# Cara membuat APK dari HP lewat GitHub Actions

Proyek ini belum berupa APK. Workflow `.github/workflows/build-apk.yml` disiapkan agar GitHub membangun APK secara online.

1. Buka https://github.com dan masuk/buat akun.
2. Buat repository baru bernama `SLOT-ANALYZER-AI` (Public atau Private).
3. Upload semua ISI folder proyek ini ke repository, termasuk folder tersembunyi `.github` dan file workflow.
4. Buka tab **Actions** pada repository.
5. Pilih **Build SLOT ANALYZER AI APK** lalu tekan **Run workflow** (jika workflow belum berjalan otomatis).
6. Tunggu sampai proses selesai dengan tanda hijau.
7. Buka hasil run tersebut, cari **Artifacts**, lalu unduh `SLOT-ANALYZER-AI-debug-apk`.
8. Ekstrak ZIP hasil unduhan. File `app-debug.apk` adalah APK untuk dipasang di Android.

Catatan:
- APK debug cocok untuk uji coba pribadi, bukan rilis Play Store.
- Jika GitHub menampilkan error, kirim screenshot bagian error agar bisa diperbaiki.
- Aplikasi ini hanya mencatat dan menghitung statistik sesi secara manual. Tidak memprediksi kemenangan, tidak membobol permainan, dan tidak menjamin keuntungan.
