# SLOT ANALYZER AI — Android starter project

Starter project Android native (Kotlin), tampilan hitam + ungu neon.

## Fitur awal
- Input manual nama permainan, nilai taruhan, dan hasil kembali.
- Menghitung total taruhan, total kembali, RTP teramati, frekuensi catatan dengan hasil kembali lebih besar dari taruhan, dan selisih sesi.
- Riwayat 30 catatan terakhir dalam sesi.
- Reset sesi.

## Membuka dan membangun APK
1. Ekstrak ZIP.
2. Buka folder `SlotAnalyzerAI` menggunakan Android Studio.
3. Tunggu Gradle Sync (perlu internet untuk mengunduh Android Gradle Plugin).
4. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK debug biasanya muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan
Ini adalah kode sumber awal, belum berupa APK terkompilasi. Perlu Android Studio/Android SDK untuk membangun APK.
Data saat ini hanya disimpan selama aplikasi berjalan; belum ada database permanen.
RTP yang dihitung adalah rasio hasil kembali terhadap taruhan dari data input, bukan RTP resmi, bukan prediksi, dan bukan cara mengalahkan bandar.
