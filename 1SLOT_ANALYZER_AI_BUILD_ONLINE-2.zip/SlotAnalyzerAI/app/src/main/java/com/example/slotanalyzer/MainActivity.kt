package com.example.slotanalyzer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.*
import android.text.InputType
import java.text.NumberFormat
import java.util.Locale

class MainActivity : Activity() {
    private val bg = Color.rgb(12, 10, 20)
    private val panel = Color.rgb(29, 23, 43)
    private val purple = Color.rgb(190, 95, 255)
    private val white = Color.rgb(246, 241, 255)
    private val muted = Color.rgb(178, 164, 195)
    private var totalBet = 0.0
    private var totalReturn = 0.0
    private var spins = 0
    private var wins = 0
    private lateinit var stats: TextView
    private lateinit var history: TextView
    private lateinit var gameName: EditText
    private lateinit var betInput: EditText
    private lateinit var returnInput: EditText
    private val records = mutableListOf<String>()
    private val money = NumberFormat.getNumberInstance(Locale("id", "ID"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 28)
        }
        scroll.addView(root)
        setContentView(scroll)

        val brand = TextView(this).apply {
            text = "SLOT ANALYZER AI"
            textSize = 25f; setTextColor(purple); typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(brand)
        root.addView(label("ANALISIS STATISTIK • INPUT MANUAL"))
        root.addView(space(18))

        val intro = card()
        intro.addView(title("Dashboard"))
        intro.addView(label("Catat spin dan nilai taruhan/hasil untuk melihat statistik sesi."))
        root.addView(intro)

        root.addView(space(14))
        val form = card()
        form.addView(title("Catat hasil spin"))
        gameName = edit("Nama permainan / provider")
        betInput = edit("Nilai taruhan (Rp)", true)
        returnInput = edit("Total hasil kembali (Rp)", true)
        form.addView(gameName); form.addView(betInput); form.addView(returnInput)
        val add = Button(this).apply {
            text = "SIMPAN HASIL SPIN"
            setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(purple))
            setOnClickListener { addRecord() }
        }
        form.addView(add)
        root.addView(form)

        root.addView(space(14))
        val statCard = card()
        statCard.addView(title("Statistik sesi"))
        stats = TextView(this).apply { setTextColor(white); textSize = 15f }
        statCard.addView(stats)
        val reset = Button(this).apply {
            text = "RESET SESI"; setTextColor(white)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(75, 48, 91)))
            setOnClickListener { resetSession() }
        }
        statCard.addView(reset)
        root.addView(statCard)

        root.addView(space(14))
        val histCard = card()
        histCard.addView(title("Riwayat catatan"))
        history = TextView(this).apply { setTextColor(muted); textSize = 13f; text = "Belum ada data." }
        histCard.addView(history)
        root.addView(histCard)

        root.addView(space(16))
        val note = TextView(this).apply {
            text = "PENTING: RTP di sini hanya perhitungan dari data yang Anda masukkan, bukan RTP resmi atau prediksi spin berikutnya. Hasil slot bersifat acak; aplikasi tidak dapat mengalahkan bandar atau menjamin kemenangan. Tetapkan batas pengeluaran."
            setTextColor(muted); textSize = 12f
        }
        root.addView(note)
        updateStats()
    }

    private fun addRecord() {
        val game = gameName.text.toString().ifBlank { "Permainan tanpa nama" }
        val bet = betInput.text.toString().replace(".", "").replace(",", "").toDoubleOrNull()
        val ret = returnInput.text.toString().replace(".", "").replace(",", "").toDoubleOrNull()
        if (bet == null || bet <= 0 || ret == null || ret < 0) {
            Toast.makeText(this, "Isi taruhan (> 0) dan hasil kembali (minimal 0).", Toast.LENGTH_LONG).show()
            return
        }
        totalBet += bet
        totalReturn += ret
        spins++
        if (ret > bet) wins++
        records.add(0, "$game • Taruhan Rp${money.format(bet)} • Kembali Rp${money.format(ret)}")
        betInput.text.clear(); returnInput.text.clear()
        updateStats()
    }

    private fun updateStats() {
        val rtp = if (totalBet > 0) totalReturn / totalBet * 100 else 0.0
        val winRate = if (spins > 0) wins.toDouble() / spins * 100 else 0.0
        val net = totalReturn - totalBet
        stats.text = "Jumlah catatan: $spins\nTotal taruhan: Rp${money.format(totalBet)}\nTotal kembali: Rp${money.format(totalReturn)}\nRTP teramati: ${"%.2f".format(rtp)}%\nCatatan dengan hasil > taruhan: $wins (${ "%.1f".format(winRate) }%)\nSelisih sesi: Rp${money.format(net)}"
        history.text = if (records.isEmpty()) "Belum ada data." else records.take(30).joinToString("\n\n")
    }

    private fun resetSession() {
        totalBet = 0.0; totalReturn = 0.0; spins = 0; wins = 0; records.clear()
        updateStats()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(16, 15, 16, 15)
        setBackgroundColor(panel)
    }
    private fun title(s: String) = TextView(this).apply {
        text = s; textSize = 18f; setTextColor(white); typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, 8)
    }
    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 12f; setTextColor(muted); setPadding(0, 5, 0, 8)
    }
    private fun edit(hintText: String, numeric: Boolean = false) = EditText(this).apply {
        hint = hintText; setHintTextColor(muted); setTextColor(white); textSize = 15f
        setSingleLine(true)
        if (numeric) inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        setPadding(12, 8, 12, 8)
    }
    private fun space(h: Int) = Space(this).apply { layoutParams = LinearLayout.LayoutParams(1, h) }
}
